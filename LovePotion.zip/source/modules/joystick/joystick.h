#pragma once

namespace love
{
	class Joystick
	{

	};
}