#pragma once

int quadNew(lua_State * L);

int quadGC(lua_State * L);

int initQuadClass(lua_State * L);