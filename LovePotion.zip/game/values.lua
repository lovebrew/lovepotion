jumpForce = 2 * 60
jumpForceAdd = 1 * 60

SPAWN_X = 0
SPAWN_Y = 0

chargeEasterEgg = false
circlePadEnabled = false

turtlePunchDuration = 0.75
turtlePunchForce = 80
turtleInvincible = false