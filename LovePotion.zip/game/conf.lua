function love.conf(t)
	t.console = false
	t.identity = "TurtleTale"
end
