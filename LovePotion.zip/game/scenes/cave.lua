return
{
	{"freezeplayer"},
	{"dialog", {"?", "Whomever finds this letter, bear in mind that it is near impossible to escape. I've tried countless times to destroy those crates.. I broke my shoulder from it. Please take this knowledge and apply it.."}},
	{"sleep", 0.5},
	{"giveability", "punch"},
	{"unfreezeplayer"}
}